# Handoff: EMP Protocol-Side Redesign

## Overview
Three design directions for the **protocol (advertiser) side** of EMP — End-user Messaging Protocol. The current UI is too horizontal and scroll-heavy; every direction here fits a fixed **1240×820** desktop frame with no scrolling, so the whole moderate → pay → send chain is legible at a glance.

The three options are alternatives, not a set to ship together. Pick one before implementing (or combine per the notes below).

## About the Design Files
`EMP Redesign.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing intended look, layout, and copy. It is **not production code to copy**. Recreate these designs in the EMP codebase's own environment using its established patterns (per SPEC.md §11: Next.js + TypeScript + Tailwind, wagmi/viem + RainbowKit, SIWE). The HTML uses inline styles for streaming reasons; translate them to Tailwind classes or the project's token system.

Open the file in a browser to see the designs. Each option is tagged with a visible id badge (`1a`, `1b`, `1c`).

## Fidelity
**High-fidelity.** Colors, type, spacing, and copy are final-intent. Recreate pixel-close using the codebase's libraries. All data shown is representative sample data, not real numbers.

## Screens / Views

### 1a — "Console" · Protocol campaign dashboard
**Purpose:** the protocol's home. See every campaign's state and act on the one that needs action.

**Layout:** CSS grid, `216px` left rail + fluid main. Height 820px, no scroll.
- **Left rail:** `border-right: 1px solid rgba(255,255,255,.07)`, `background #080b0e`, padding `22px 16px`, flex column, `gap: 26px`.
  - Logo: 22×22 rounded 5px square, `#35e6f2` fill, letter "E" in `#04070a`, JetBrains Mono 700/11px. Wordmark "EMP", JetBrains Mono 700/14px, `letter-spacing .06em`.
  - Nav group with eyebrow "PROTOCOL" (JetBrains Mono 500/9.5px, `letter-spacing .14em`, `#5c6a73`, padding `0 10px 8px`). Items: Campaigns (active), New campaign, Audience explorer, Payments, Settings. Each: `padding 8px 10px`, `border-radius 6px`, `gap 9px`, a 4×4px `border-radius 2px` dot. Active = `background rgba(53,230,242,.1)`, text `#35e6f2`, dot `#35e6f2`, weight 500. Inactive = text `#8b979f`, dot `#313b42`.
  - Bottom (`margin-top:auto`, `gap 10px`): stat card — label "ACTIVE CAMPAIGNS", value `2` (JetBrains Mono 500/20px), sub "1 sending · 1 in review" in `#5ef2a8`; card is `padding 12px`, `border 1px solid rgba(255,255,255,.08)`, `radius 8px`. Then wallet chip: 18px circle with `linear-gradient(135deg,#35e6f2,#9a7bff)` + truncated address `0x8f2c…41ab` (JetBrains Mono 11px, `#c3ced4`).
  - ⚠️ **Do not show aggregate or monthly spend anywhere in the chrome.** Per-campaign spend in the table is fine; a "spend this month" style total is explicitly out.
- **Main:** padding `26px 30px`, flex column, `gap 22px`.
  - **Header row:** title "Campaigns" (Space Grotesk 600/22px, `letter-spacing -.01em`), sub "Aggregate results only — EMP never exposes recipients." (12.5px, `#7d8b94`). Right: secondary button "Export CSV" (`padding 9px 14px`, `1px solid rgba(255,255,255,.12)`, `radius 7px`, `#c3ced4`) and primary "New campaign" (`padding 9px 16px`, `radius 7px`, `background #35e6f2`, text `#04070a`, weight 600).
  - **Stat tiles:** `grid-template-columns: repeat(4,1fr)`, `gap 12px`. Each tile `background #0a0e11`, `border 1px solid rgba(255,255,255,.08)`, `radius 9px`, `padding 15px 16px`, `gap 9px`. Eyebrow = JetBrains Mono 500/9.5px `letter-spacing .12em` `#5c6a73`; value = JetBrains Mono 500/26px (percent suffix at 15px `#7d8b94`); footnote 11.5px.
    1. MESSAGEABLE AUDIENCE · `12,904` · "+412 verified this week" (`#5ef2a8`)
    2. DELIVERED · `97.2%` · "across 6 sent campaigns"
    3. CTA CLICK RATE · `11.4%` · "1,041 clicks tracked"
    4. COST PER USER · `$1.00` · "flat · locked at approval"
  - **Campaign table:** container `background #0a0e11`, `border 1px solid rgba(255,255,255,.08)`, `radius 9px`, `overflow hidden`. Every row is the same grid: `1.6fr .9fr .8fr .9fr .9fr .7fr`, `gap 14px`, `padding 15px 18px`, `border-bottom 1px solid rgba(255,255,255,.05)` (header row uses `padding 11px 18px` and `rgba(255,255,255,.07)`; last row has no border). Columns: CAMPAIGN / STATUS / AUDIENCE / DELIVERED / CLICKS / SPEND (right-aligned).
    - Campaign cell: name (weight 500) + meta line "`<category>` · `<chain>`" (JetBrains Mono 10.5px, `#5c6a73`).
    - Status pills: `padding 4px 9px`, `radius 5px`, JetBrains Mono 500/10.5px. COMPLETE `rgba(94,242,168,.12)`/`#5ef2a8`; SENDING `rgba(53,230,242,.12)`/`#35e6f2`; AWAITING PAY `rgba(255,203,107,.14)`/`#ffcb6b`; IN REVIEW `rgba(154,123,255,.14)`/`#9a7bff`; DRAFT `rgba(255,255,255,.07)`/`#8b979f`.
    - Delivered / clicks cells: mono 12px value over a 3px-tall progress bar (`background rgba(255,255,255,.08)`, `radius 2px`) filled to the percentage — delivered fill `#35e6f2`, clicks fill `#9a7bff`. Empty values render as `—` in `#4a565e`.
    - Sample rows: stETH boost — 4.9% APR (Yields · Base, COMPLETE, 3,204, 98.1%, 12.8%, $3,204); Perps v3 launch (New products · Arbitrum, SENDING, 4,182, 61.0%, 9.2%, $4,182); OTC desk — size trades (New utility · Ethereum, AWAITING PAY, 2,860, —, —, $2,860 in `#ffcb6b`); Points season 2 (New features · Optimism, IN REVIEW, ~5,100, —, —, est. $5,100); Untitled draft (DRAFT, all `—`).
  - **Action banner** (only rendered when a campaign is approved-and-unpaid): `border 1px dashed rgba(255,203,107,.35)`, `background rgba(255,203,107,.05)`, `radius 9px`, `padding 13px 16px`, `gap 12px`. 6px amber dot, copy in `#e0d3b6` ("… is approved and snapshotted — pay 2,860 USDC from `0x8f2c…41ab` within 24h or the snapshot expires."), then a "Pay now" button (`background #ffcb6b`, text `#241c08`, weight 600, `radius 6px`, `padding 8px 14px`) at `margin-left:auto`.

### 1b — "Pulse composer" · Campaign creation, one screen
**Purpose:** create a campaign without a multi-page wizard. Targeting, message, audience, and cost are all visible simultaneously; cost recalculates live as targeting changes.

**Layout:** vertical flex — top bar, then grid `210px | 1fr | 320px` filling the rest. Total 820px, no scroll.
- **Top bar:** `padding 16px 26px`, `border-bottom 1px solid rgba(255,255,255,.07)`, `gap 16px`. "EMP" wordmark, 1×16px divider `rgba(255,255,255,.12)`, "New campaign", then status "DRAFT · autosaved 12s ago" (JetBrains Mono 10.5px, `#5c6a73`). Right: "Save draft" (outline) + "Submit for moderation" (`#35e6f2` fill).
- **Step rail (left):** 5 steps, each a `gap 12px` row of [marker column | text]. Marker = 20px circle; completed = filled `#35e6f2` with `#04070a` numeral; current = `1px solid #35e6f2`, text `#35e6f2`; future = `1px solid rgba(255,255,255,.18)`, `#5c6a73`. Connector = 1px vertical line, `min-height 44px`, `#35e6f2` when the step is complete else `rgba(255,255,255,.12)`. Each step has a name (weight 500) plus a two-line mono 10.5px sub.
  1. Target — "3 categories / 4,182 messageable" 2. Compose (current) — "text + image / 2 CTAs" 3. Moderation — "EMP reviews / ~2h typical" 4. Pay — "locked at snapshot" 5. Send — "queued burst"
  - Rail footer card (`margin-top:auto`): "MODERATE → PAY → SEND. Rejected messages are never charged."
- **Compose column (centre):** `padding 24px 26px`, `gap 18px`. Section eyebrows use the same mono 9.5px `.12em` `#5c6a73` style, numbered (`01 · TARGET CATEGORIES`, `02 · MESSAGE`).
  - Category chips: `padding 7px 13px`, `radius 20px`, 12.5px. Selected = `background rgba(53,230,242,.12)`, `border 1px solid rgba(53,230,242,.45)`, text `#35e6f2`. Unselected = `border 1px solid rgba(255,255,255,.14)`, `#8b979f`. Taxonomy is admin-configured (SPEC §7): Yields, New features, New products, New protocols, New utility, Everything.
  - Message card: `background #0a0e11`, `border 1px solid rgba(255,255,255,.1)`, `radius 9px`, `padding 16px`, `gap 14px`. Body text 13.5px/1.6. Image slot = 110px tall, `radius 7px`, striped placeholder `repeating-linear-gradient(135deg,#0d1216 0 8px,#101619 8px 16px)`, caption "campaign image · 1200×628" — **replace with a real upload control**. CTA buttons in a `gap 9px` flex row, first = cyan outline/tint, rest = neutral outline, `padding 11px`, `radius 7px`. Footer note above a `1px solid rgba(255,255,255,.06)` top border: "CTAs auto-wrapped → emp.xyz/r/:token · click-through is the only engagement signal Telegram gives us".
  - Three payment meta cards in a row (CHAIN / PAY WITH / FROM): `flex 1`, `padding 13px 15px`, `border 1px solid rgba(255,255,255,.08)`, `radius 8px`, `background #0a0e11`. Chain list must come from config (CLAUDE.md rule 5); tokens USDC/USDT/ETH; FROM is the SIWE-authenticated wallet, since payment verification is sender-based.
- **Live panel (right):** `background #080b0e`, `border-left 1px solid rgba(255,255,255,.07)`, `padding 24px 22px`, `gap 20px`.
  - **Pulse graphic:** 150px-tall centred stack. Two 120px rings (`border 1px solid rgba(53,230,242,.5)`, `border-radius 60px`) animate `empPulse` — `@keyframes empPulse { 0% { transform: scale(.6); opacity:.55 } 100% { transform: scale(1.9); opacity:0 } }`, `2.6s ease-out infinite`, second delayed `1.3s`. Centre disc 104px, `border 1px solid rgba(53,230,242,.35)`, `background radial-gradient(circle, rgba(53,230,242,.14), transparent 70%)`, holding the count `4,182` (JetBrains Mono 500/24px `#35e6f2`) over label "MESSAGEABLE". Respect `prefers-reduced-motion` — hold the rings static.
  - **Breakdown rows** (12.5px, label `#7d8b94`, value mono): Matching categories `6,930` · Verified Telegram `4,182` · Cost per user `$1.00`; 1px divider; "Est. cost" with `$4,182` at mono 500/22px. Note beneath: cost is locked exactly at approval against the snapshot; rejected campaigns are never charged.
  - **"WHAT YOU'LL SEE BACK" card** (`margin-top:auto`): "Delivered % · click % per CTA · audience size" then the boundary note — never wallets, handles, or per-user rows, and there is no read metric.

### 1c — "Signal" · Bold dashboard variant
**Purpose:** same job as 1a, leaning into the electromagnetic-pulse concept. Use if the brand should read louder.

**Layout:** vertical flex — hero band, campaign list, footer strip. 820px, no scroll.
- **Hero band:** `padding 26px 34px 22px`, `border-bottom 1px solid rgba(255,255,255,.07)`, background = two stacked radial gradients: `radial-gradient(120% 180% at 12% 0%, rgba(154,123,255,.16), transparent 60%)` + `radial-gradient(90% 160% at 78% 0%, rgba(53,230,242,.14), transparent 62%)`.
  - Top row: "E M P" (JetBrains Mono 700/13px, `letter-spacing .24em`) + an org chip (`radius 5px`, `1px solid rgba(255,255,255,.14)`, mono 10px, `#8b979f`). Right: pill "History" (outline, `radius 20px`) and pill "Fire a pulse" — `background linear-gradient(90deg,#35e6f2,#9a7bff)`, text `#04070a`, weight 700.
  - Below, a `gap 44px` row: (a) "REACHABLE HUMANS" eyebrow + `12,904` at **JetBrains Mono 700/62px, `letter-spacing -.03em`** + delta "▲ 412 / 7d" in `#5ef2a8` + line "One wallet, one account, one Telegram. Audience ≈ distinct people." (b) A 78px-tall 12-bar histogram, `gap 3px`, bars flex-1, heights 18/31/26/44/38/92/64/47/55/34/41/22 %, first six cyan tints rising to `linear-gradient(180deg,#35e6f2,rgba(53,230,242,.3))`, the rest violet tints fading out. (c) DELIVERED `97.2%` and CLICKED `11.4%` (`#9a7bff`) at mono 500/30px.
- **Campaign rows:** header strip "PULSES" + hairline + legend ("● DELIVERY" cyan, "● CLICKS" violet). Each row: `border 1px solid rgba(255,255,255,.09)`, `radius 11px`, `padding 17px 20px`, grid `1fr 240px 130px`, `gap 22px`, `align-items center`. Name is Space Grotesk 600/16px with an inline status pill; meta line is mono 10.5px `#5c6a73`. Middle column = a 38px-tall 8-bar trace (cyan bars = delivery over time, violet = clicks). Right column = the click rate at mono 500/20px over a "CTA CLICKS" caption.
  - Active/sending row gets `background linear-gradient(90deg, rgba(53,230,242,.07), transparent 55%)`.
  - Awaiting-payment row: `border 1px solid rgba(255,203,107,.3)`, `background rgba(255,203,107,.04)`, middle column replaced by the snapshot note, right column a "Pay $2,860" amber button. Meta shows the snapshot expiry countdown.
  - In-moderation row: `opacity .72`, right column `—`, meta reads "not charged until approved".
- **Footer strip:** two cards, `gap 12px`. Left (flex 1): "PRIVACY / BOUNDARY" label + "You see counts and rates. EMP holds the wallets and Telegram IDs — enforced at the query layer, not just here." Right (300px): "TREASURY" + "USDC · USDT · ETH" + "● live" in `#5ef2a8`.

## Interactions & Behavior
- **Nav:** left-rail items route; "New campaign" opens the 1b composer.
- **Category chips (1b):** toggle on click. Every toggle refetches the messageable count and re-derives est. cost = `count × flat_cost_per_user`. Debounce ~250ms; show the count in a skeleton/dimmed state while in flight rather than jumping to zero. "Everything" selects all and disables the others.
- **Est. cost is an estimate until approval.** On approval the backend snapshots recipients and locks cost; the UI must then switch the label from "Est. cost" to "Locked cost" and show the snapshot expiry countdown (24h in the mock).
- **Submit for moderation:** disabled until ≥1 category, non-empty body, and ≥1 valid CTA URL. On success the campaign moves to IN REVIEW and the composer becomes read-only.
- **Pay now / Pay $X:** opens the wallet flow, prefilled with treasury address for the campaign's chain, token, and exact amount. Must pay **from the authenticated wallet** — sender-based verification. While watching the chain, show a "verifying payment" state; on verify, status → SENDING.
- **Sending state:** delivered % polls (or streams) and the progress bar / trace animates upward. Statuses map 1:1 to SPEC: draft, in review, approved, awaiting payment, sending, complete.
- **Hover states:** table/campaign rows lighten to `rgba(255,255,255,.02)`; buttons lift brightness ~8%; nav items go to `rgba(255,255,255,.04)` with text `#e8eef2`. Transition `120ms ease`.
- **Empty states:** no campaigns → the table area shows the pulse graphic from 1b at 60% opacity with "No pulses yet" and the New campaign button. Not designed in the mock; follow this pattern.
- **Errors:** wrong-amount / wrong-token / late payment need an inline amber-to-red banner in the same slot as the pay banner, with the discrepancy stated in mono.
- **Responsive:** desktop-only (1240px design width). Below ~1100px, the 1b right panel should collapse to a sticky bottom bar showing count + est. cost + primary action.
- `prefers-reduced-motion: reduce` → disable `empPulse` and any bar-growth animation.

## State Management
- `session`: SIWE address, protocol id, approval status (`pending|approved|rejected|suspended`). Un-approved protocols see a gated state instead of the composer.
- `campaigns[]`: id, name, status, targetCategoryIds, chain, token, snapshotCount, cost, deliveredPct, clickPct, ctas[].
- `draft`: selectedCategoryIds, body, imageRef, ctas[{label,url}], chain, token — autosave on change (the "autosaved 12s ago" chip reflects this).
- `audiencePreview`: { matchingCount, messageableCount, loading } — derived server-side; the client must never receive user rows.
- `payment`: { status: idle|awaiting|verifying|verified|failed, txHash, expiresAt }.
- Data fetching: campaign list + per-campaign aggregates; audience preview on targeting change; payment status polling while `awaiting|verifying`.
- **Query-layer rule:** all protocol-facing endpoints return counts/rates only (CLAUDE.md rule 1). Do not add a per-recipient endpoint for the UI's convenience.

## Design Tokens
**Colors**
- Canvas `#06080a` · panel `#0a0e11` · rail/inset `#080b0e`
- Borders: hairline `rgba(255,255,255,.07)`, card `rgba(255,255,255,.08)`, input `rgba(255,255,255,.10)`, strong `rgba(255,255,255,.14)`, row split `rgba(255,255,255,.05)`
- Text: primary `#e8eef2`, secondary `#c3ced4`, muted `#8b979f`, dim `#7d8b94`, faint `#5c6a73`, disabled `#4a565e`
- Accents: cyan `#35e6f2` (primary/delivery), violet `#9a7bff` (clicks/secondary), green `#5ef2a8` (positive), amber `#ffcb6b` (action required), on-accent text `#04070a`, on-amber text `#241c08`
- Tints: `rgba(53,230,242,.08 / .10 / .12 / .14)`, `rgba(154,123,255,.14 / .16)`, `rgba(94,242,168,.12)`, `rgba(255,203,107,.04 / .05 / .14 / .16)`

**Typography** — Space Grotesk (400/500/600/700) for UI and headings; JetBrains Mono (400/500/700) for all numbers, labels, addresses, and eyebrows. Both from Google Fonts; substitute the codebase's equivalents only if it already ships a geometric sans + mono pair.
- Display 62/1 700 `-.03em` · Title 22/1.1 600 `-.01em` · Metric XL 30/1 500 mono · Metric 26/1 500 mono · Metric S 20-22/1 500 mono · Card title 16/1 600 · Body 13.5/1.6 · UI 13/1.4 · UI small 12.5 · Meta 11.5 · Mono meta 10.5-12 · Eyebrow 9.5 mono 500 `letter-spacing .12–.16em` uppercase

**Spacing** — 2, 3, 4, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 22, 24, 26, 30, 34, 44 px (snap to the codebase's nearest 4px scale).
**Radius** — 2 (bars), 5, 6, 7, 8, 9 (cards), 10, 11 (rows), 20 (pills/chips), 50% (avatars).
**Shadows** — none inside the UI; depth comes from background steps and 1px borders. Glow is done with radial gradients and tints, never `box-shadow`.
**Layout** — design width 1240px, height 820px. 1a: `216px | 1fr`. 1b: `210px | 1fr | 320px`. Table grid: `1.6fr .9fr .8fr .9fr .9fr .7fr`.

## Assets
No image or icon assets. Everything is type, CSS gradients, and 1px borders. Two placeholders to replace with real implementations:
- The campaign image slot in 1b (striped CSS placeholder → real upload component, 1200×628).
- Chain and token names are text; if the codebase has chain/token logos, use them at 16px in the meta cards.

## Files
- `EMP Redesign.dc.html` — all three options on one canvas, ids `1a`, `1b`, `1c`. Open in any browser.
- Source of truth for behavior: repo `SPEC.md` (§4 journeys, §6 payments, §7/§7.5 categories + sybil resistance, §9 privacy, §13 brand) and `CLAUDE.md` (non-negotiable rules).
