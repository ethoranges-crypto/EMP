repo: ethoranges-crypto/EMP
branch: main

## Last sync
date: 2026-08-26T18:05:00Z

### Updated in this project
- Read README.md, CLAUDE.md, SPEC.md (repo contains no UI code yet).
- Designed the public landing page (/) from SPEC §1, §9, §13.
- Designed the /user registration flow (5 states) from SPEC §4.1, §7, §7.5, §8.
- Note: "github UI design workflow.zip" is not present in the repo at main.

## Screen map
| Project screen | Repo files |
| --- | --- |
| EMP Landing + User Flow.dc.html — 01 Landing / | SPEC.md §1–3, §5–6, §9, §13; README.md |
| EMP Landing + User Flow.dc.html — 02 /user states 1–5 | SPEC.md §4.1, §7, §7.5, §8, §9; CLAUDE.md (auth, Telegram realities) |
